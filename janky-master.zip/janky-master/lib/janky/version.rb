module Janky
  VERSION = "0.11.1"
end
